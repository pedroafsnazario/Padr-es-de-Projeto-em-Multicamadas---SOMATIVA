package com.example.mypokedexoficial.domain

data class PokemonType(
    val name: String
)